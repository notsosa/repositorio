/*
 * UART.h
 *
 * Created: 3/2/2025 6:33:40 PM
 *  Author: cssos
 */ 


#ifndef UART_H_
#define UART_H_

void initUART(void);
void WriteUART(char Caracter);
void TextUART(char * Texto);





#endif /* UART_H_ */