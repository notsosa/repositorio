/*
 * proyecto 1 slave 2 digital 2.c
 *
 * Created: 3/3/2025 1:10:39 AM
 * Author : cssos
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <util/delay.h>
#include <util/twi.h>
#include "ADC.h"
#include "UART.h"
#include "I2C_SLAVE.h"
#include "PWM.h"

void init_ports(void);

// Direcci�n del esclavo I�C
#define slave_keu 0x40

// Variable para recibir datos v�a I�C (volatile para que se actualice en la ISR)
volatile uint8_t buffer = 0;

// Arreglo para enviar 3 bytes v�a I�C:
// sensorData[0]: sensor de humedad (ADC0, 0-255)
// sensorData[1]: estado del servo (0 = 0�, 1 = 90�)
// sensorData[2]: estado del motor DC (0 = apagado, 1 = encendido)
volatile uint8_t sensorData[3] = {0, 0, 0};

// Flag para nuevo dato de humedad (ADC0)
volatile uint8_t newValue = 0;

// Variables para conversi�n de humedad a porcentaje
float humedad = 0;
char hum_string[16];
char msg[32];

// �ndice para transmitir datos v�a I�C
volatile uint8_t sensorIndex = 0;

// Se usa ADC0 para el sensor de humedad
volatile uint8_t channel = 0;

// Calibraciones para humedad en 8 bits (se asume: 0% ? seco (dry = 255), 100% ? h�medo (wet = 75))
#define wet 75
#define dry 255

// Estados digitales:
// servoState: 0 ? servo en 0� (cerrado), 1 ? servo en 90� (abierto)
// motorState: 0 ? motor apagado, 1 ? motor encendido
volatile uint8_t servoState = 0;
volatile uint8_t motorState = 0;

int main(void)
{
    cli();
    
    // Configura pines para TWI: PC4 (SDA) y PC5 (SCL) como entradas con pull-up
    DDRC &= ~((1 << PORTC4) | (1 << PORTC5));
    PORTC |= (1 << PORTC4) | (1 << PORTC5);
    
    // Configura el pin ADC para el sensor de humedad (A0) como entrada sin pull-up
    DDRC &= ~(1 << PORTC0);
    PORTC &= ~(1 << PORTC0);
    
    // Configura un LED (ejemplo en PB5) para indicar actividad
    DDRB |= (1 << DDB5);
    
    I2C_slave_init(slave_keu);
    init_ports();
    
    // Inicializa ADC (ADLAR=1 para 8 bits), UART y PWM0
    ADC_init(128);
    initUART();
    initPWM0();
    
    // Selecciona ADC0 para el sensor de humedad
    ADC0();
    channel = 0;
    
    sei();                // Habilita interrupciones globales
    conversion();         // Inicia la primera conversi�n ADC
    
    while(1)
    {
        // Depuraci�n: Imprime el contenido actual de "buffer"
        {
            char dbg[10];
            itoa(buffer, dbg, 10);
            sprintf(msg, "Buffer: %s\r\n", dbg);
            TextUART(msg);
        }
        
        // Extrae el comando recibido en una variable temporal y limpia buffer
        uint8_t cmd = buffer;
        buffer = 0;  // Limpiar inmediatamente
        
        if(cmd != 0)
        {
            sprintf(msg, "Cmd: %c\r\n", cmd);
            TextUART(msg);
            
            // Toggle del servo: 's' invierte el estado
            if(cmd == 's')
            {
                servoState = !servoState;
                if(servoState)
                    TextUART("Toggle: Servo set to 90�\r\n");
                else
                    TextUART("Toggle: Servo set to 0�\r\n");
            }
            // Comando para el motor DC: 'S' activa el motor por 4 segundos y luego lo apaga
            else if(cmd == 'S')
            {
                TextUART("Received 'S': Activating Motor for 4 sec\r\n");
                motorState = 1;
                PORTD |= (1 << DDD7); // Enciende motor
                _delay_ms(4000);
                motorState = 0;
                PORTD &= ~(1 << DDD7); // Apaga motor
                TextUART("Motor turned OFF\r\n");
            }
        }
        
        // Procesa la lectura del sensor de humedad
        if(newValue)
        {
            newValue = 0;
            humedad = ((float)(dry - sensorData[0]) / (dry - wet)) * 100.0;
            if(humedad > 100.0) humedad = 100.0;
            if(humedad < 0.0)   humedad = 0.0;
            dtostrf(humedad, 6, 2, hum_string);
            sprintf(msg, "Hum: %s %%\r\n", hum_string);
            TextUART(msg);
        }
        
        // Actualiza el arreglo sensorData para I�C:
        sensorData[1] = servoState;
        sensorData[2] = motorState;
        
        // Actualiza el PWM del servo seg�n el estado actual
        servo_set_state(servoState);
        
        // Depuraci�n: Env�a el valor actual de OCR0A v�a UART (PWM del servo)
        {
            char dutyStr[10];
            itoa(OCR0A, dutyStr, 10);
            sprintf(msg, "OCR0A = %s\r\n", dutyStr);
            TextUART(msg);
        }
        
        // Depuraci�n: Env�a el estado del motor v�a UART
        {
            char motorStr[10];
            itoa(motorState, motorStr, 10);
            sprintf(msg, "Motor state = %s\r\n", motorStr);
            TextUART(msg);
        }
        
        _delay_ms(500);
    }
    
    return 0;
}

void init_ports(void)
{
    // Inicializa el pin PD5 para el motor DC: config�ralo como salida y ponlo en bajo.
    DDRD |= (1 << DDD7);
    PORTD &= ~(1 << DDD7);
}

// ISR de TWI para la comunicaci�n I�C
ISR(TWI_vect)
{
    uint8_t estado = TWSR & 0xF8;
    switch(estado)
    {
        case 0x60: // SLA+W recibido
        case 0x70:
            TWCR |= (1 << TWINT) | (1 << TWEA) | (1 << TWEN) | (1 << TWIE);
            break;
        case 0x80: // Dato recibido, ACK retornado
        case 0x90:
            buffer = TWDR;
            TWCR = (1 << TWINT) | (1 << TWEA) | (1 << TWEN) | (1 << TWIE);
            break;
        case 0xA8: // SLA+R recibido
        case 0xB8: // Dato transmitido, ACK recibido
            TWDR = sensorData[0];
            TWCR = (1 << TWINT) | (1 << TWEA) | (1 << TWEN) | (1 << TWIE);
            break;
        default:
            TWCR |= (1 << TWINT) | (1 << TWSTO) | (1 << TWEA) | (1 << TWEN) | (1 << TWIE);
            break;
    }
}

// ISR de ADC: se usa ADC0 para el sensor de humedad
ISR(ADC_vect)
{
    uint8_t valor = ADCH;
    sensorData[0] = valor;
    newValue = 1;
    ADCSRA |= (1 << ADIF);
    conversion();
}
