/*
 * PWM.c
 *
 * Modificado para usar �nicamente PWM0 (Timer0) en Fast PWM, no invertido,
 * para controlar un servo que se mueve de 0� a 90�.
 *
 * Con F_CPU=16MHz y prescaler 1024, cada tick es aproximadamente 64�s.
 * Se asume:
 *   0� ? ~1ms de pulso ? 1ms / 64�s ? 16 ticks.
 *  90� ? ~1.5ms de pulso ? 1.5ms / 64�s ? 23.44, redondeamos a 24 ticks.
 */

#include <avr/io.h>
#include "PWM.h"

#define SERVO_CLOSED 16  // Aproximadamente 16 ticks (~1ms)
#define SERVO_OPEN   31  // Aproximadamente 24 ticks (~1.5ms)

void initPWM0(void)
{
    // Configura PD6 (OC0A) como salida.
    DDRD |= (1 << DDD6);
    
    // Configura Timer0 en Fast PWM (modo 3: WGM00 y WGM01 = 1, TOP=0xFF)
    // Salida no invertida: COM0A1=1, COM0A0=0.
    TCCR0A = (1 << COM0A1) | (1 << WGM00) | (1 << WGM01);
    
    // Configura el prescaler a 1024: CS02=1 y CS00=1.
    TCCR0B = (1 << CS02) | (1 << CS00);
    
    // Inicializa el duty cycle para la posici�n 0�.
    OCR0A = SERVO_CLOSED;
}

void servo_set_state(uint8_t state)
{
    if(state == 0)
        OCR0A = SERVO_CLOSED;
    else
        OCR0A = SERVO_OPEN;
}
