/*
 * PWM.h
 *
 * Created: 3/3/2025 6:37:13 PM
 *  Author: cssos
 */ 


#ifndef PWM_H_
#define PWM_H_

// Inicializa PWM0 en Fast PWM, no invertido, para controlar un servo.
// Se usa Timer0 (OC0A en PD6) con prescaler 1024.
void initPWM0(void);

// Cambia el estado del servo:
// state = 0 ? posici�n 0� (cerrado)
// state = 1 ? posici�n 90� (abierto)
void servo_set_state(uint8_t state);

#endif /* PWM_H_ */
